<?php
/**
 * Plugin Name: z2
 * Plugin URI: https://www.freelancer.com/u/picaro3535
 * Description: Provides product quotes based on user cart or admin
 * Version: 2.0.1
 * Author: Picaro3535
 * Author URI: https://www.freelancer.com/u/picaro3535
 * Developer: Picaro3535
 * Developer URI: https://www.freelancer.com/u/picaro3535
 * Text Domain: ms-wc-qt
 * Domain Path: /languages
 * Requires at least: 4.0
 * Requires PHP: 5.6
 * Tested up to: 4.0
 * WC requires at least: 3.0
 * WC tested up to: 3.0
 */

//updated.

add_action( 'plugins_loaded', 'z2_update_func');

function z2_update_func(){
	require_once dirname( MWQT_PLUGIN_FILE ) . '/libs/plugin-update-checker/plugin-update-checker.php';
	$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
		'https://raw.githubusercontent.com/pg35/mydocs/master/plugin.json',
		__FILE__, //Full path to the main plugin file or functions.php.
		'z2'
	);
}

// this is version 2